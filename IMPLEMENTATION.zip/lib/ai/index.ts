import { generateObject, generateText } from "ai";
import { z } from "zod";
import { dbHelpers } from "../db/mock-db";
import { google } from "@ai-sdk/google";
import { openai } from "@ai-sdk/openai";
import { anthropic } from "@ai-sdk/anthropic";
import {
  generateMockInvoiceData,
  generateMockQuotationData,
  generateMockProposalData,
} from "./demo";

type LLMProvider = "gemini" | "openai" | "claude";

export type MessageIntent = "chat" | "document";

export interface IntentDetectionResult {
  intent: MessageIntent;
  templateType?: "invoice" | "quotation" | "proposal";
  confidence: number;
}

interface DocumentExtractionInput {
  userPrompt: string;
  templateType: "invoice" | "quotation" | "proposal";
  skillContent: string;
  memoryContext?: Record<string, any>;
  provider?: LLMProvider;
}

async function getActiveLLMProvider(): Promise<LLMProvider> {
  try {
    const setting = await dbHelpers.getSetting("active_llm_provider");
    return (setting?.value as LLMProvider) || "gemini";
  } catch (error) {
    console.error("Error getting LLM provider:", error);
    return "gemini";
  }
}

export function getModel(provider: LLMProvider) {
  switch (provider) {
    case "gemini":
      return google("gemini-2.5-flash");
    case "openai":
      return openai("gpt-4o-mini");
    case "claude":
      return anthropic("claude-sonnet-4-5");
    default:
      return google("gemini-2.5-flash");
  }
}

// ─── Intent Detection ──────────────────────────────────────────────────────────
// Fast heuristic-first: only call LLM if heuristic is uncertain
export async function detectIntent(
  userInput: string,
  provider: LLMProvider = "gemini",
): Promise<IntentDetectionResult> {
  const input = userInput.trim().toLowerCase();
  const wordCount = input.split(/\s+/).length;

  // ── Definite CHAT signals (no LLM needed) ──
  if (wordCount <= 4) {
    return { intent: "chat", confidence: 0.98 };
  }
  if (
    /^(hi|hello|hey|thanks|thank you|ok|okay|sure|yes|no|help|what|how|why|who|when|where|can you|do you|is it|are you)/.test(
      input,
    )
  ) {
    return { intent: "chat", confidence: 0.97 };
  }
  if (/\?$/.test(input.trim())) {
    return { intent: "chat", confidence: 0.95 };
  }

  // ── Definite DOCUMENT signals (no LLM needed) ──
  const hasAmount =
    /\$[\d,]+|[\d,]+ ?(usd|dollars?|€|£)|[\d]+ ?hours?|\d+\/hr/.test(input);
  const hasClient = /\b(for|to|client|customer|company|corp|inc|ltd)\b/.test(
    input,
  );
  const hasAction =
    /\b(create|generate|make|build|write|draft|invoice|bill|quote|quotation|proposal)\b/.test(
      input,
    );

  if (hasAction && hasClient && hasAmount) {
    // Determine template type from keywords directly
    const templateType = detectTemplateTypeHeuristic(input);
    return { intent: "document", confidence: 0.92, templateType };
  }

  // ── Uncertain — ask the LLM ──
  try {
    const result = await generateObject({
      model: getModel(provider),
      system: `Classify this message for a document generation assistant.

"document" = user wants to CREATE an invoice, quotation, or proposal with real data right now.
"chat" = greetings, questions, explanations, vague requests, anything without enough data to generate a document.

To be "document", the message MUST contain: who it's for + what service/item + a price or date.`,
      prompt: `Message: "${userInput}"`,
      schema: z.object({
        intent: z.enum(["chat", "document"]),
        templateType: z.enum(["invoice", "quotation", "proposal"]).optional(),
        confidence: z.number().min(0).max(1),
      }),
    });

    return {
      intent: result.object.intent,
      templateType: result.object.templateType,
      confidence: result.object.confidence,
    };
  } catch (error) {
    console.error("Intent detection LLM failed, defaulting to chat:", error);
    return { intent: "chat", confidence: 0.7 };
  }
}

// ─── Chat Response ─────────────────────────────────────────────────────────────
export async function generateChatResponse(
  userMessage: string,
  conversationHistory: Array<{
    role: "user" | "assistant";
    content: string;
  }> = [],
  provider?: LLMProvider,
): Promise<string> {
  const activeProvider = provider || (await getActiveLLMProvider());

  try {
    const { text } = await generateText({
      model: getModel(activeProvider),
      system: `You are a friendly assistant for a document generation platform that creates invoices, quotations, and proposals.

Your job:
- Answer questions about the platform, documents, pricing, and business practices
- Help users understand what information they need to create a document
- Have natural conversations

When users seem ready to create a document, tell them exactly what format to use. For example:
"Just say something like: 'Create an invoice for John Doe, web design services, $1500, due Feb 15'"

Keep replies concise and helpful. Do not generate document data yourself — just guide the user.`,
      messages: [
        ...conversationHistory,
        { role: "user", content: userMessage },
      ],
    });

    return text;
  } catch (error) {
    console.error("Error generating chat response:", error);
    return "I'm sorry, I encountered an error. Please try again.";
  }
}

// ─── Document Data Extraction ──────────────────────────────────────────────────
export async function extractDocumentData(
  input: DocumentExtractionInput,
): Promise<Record<string, any>> {
  const provider = input.provider || (await getActiveLLMProvider());

  let fullPrompt = input.userPrompt;
  if (input.memoryContext) {
    fullPrompt = `Context:\n${JSON.stringify(input.memoryContext, null, 2)}\n\nUser input:\n${input.userPrompt}`;
  }

  const genericSchema = z.object({
    clientName: z.string().optional(),
    clientEmail: z.string().optional(),
    clientAddress: z.string().optional(),
    invoiceNumber: z.string().optional(),
    quotationNumber: z.string().optional(),
    proposalNumber: z.string().optional(),
    invoiceDate: z.string().optional(),
    quotationDate: z.string().optional(),
    proposalDate: z.string().optional(),
    dueDate: z.string().optional(),
    validUntil: z.string().optional(),
    items: z
      .array(
        z.object({
          description: z.string().optional(),
          quantity: z.number().optional(),
          unitPrice: z.number().optional(),
          amount: z.number().optional(),
        }),
      )
      .optional(),
    subtotal: z.number().optional(),
    tax: z.number().optional(),
    total: z.number().optional(),
    notes: z.string().optional(),
    companyName: z.string().optional(),
    companyAddress: z.string().optional(),
    proposalTitle: z.string().optional(),
    introduction: z.string().optional(),
    objectives: z.array(z.string()).optional(),
    scope: z.string().optional(),
    deliverables: z.array(z.string()).optional(),
    timeline: z.string().optional(),
    cost: z.number().optional(),
    terms: z.string().optional(),
  });

  try {
    const result = await generateObject({
      model: getModel(provider),
      system: `${input.skillContent}

IMPORTANT: Always fill in reasonable defaults for missing fields:
- invoiceNumber/quotationNumber/proposalNumber: generate as "INV-001", "QUO-001", "PRO-001"
- dates: use today's date if not specified (${new Date().toISOString().split("T")[0]})
- dueDate: default to 30 days from today if not specified
- tax: default to 0 if not mentioned
- Calculate subtotal, tax, and total correctly from items
- If quantity is not specified, default to 1
- companyName: use "Your Company" if not specified`,
      prompt: fullPrompt,
      schema: genericSchema,
    });

    return result.object;
  } catch (error) {
    const errorMessage =
      error instanceof Error ? error.message : "Unknown error";

    // Fall back to demo data on auth errors
    const isAuthError =
      errorMessage.includes("credit card") ||
      errorMessage.includes("authentication") ||
      errorMessage.includes("API key") ||
      errorMessage.includes("401") ||
      errorMessage.includes("403");

    if (isAuthError) {
      console.log("[ai] Auth error — using demo data");
      if (input.templateType === "invoice")
        return generateMockInvoiceData(input.userPrompt);
      if (input.templateType === "quotation")
        return generateMockQuotationData(input.userPrompt);
      if (input.templateType === "proposal")
        return generateMockProposalData(input.userPrompt);
    }

    throw new Error(`Failed to extract document data: ${errorMessage}`);
  }
}

// ─── Provider Config ───────────────────────────────────────────────────────────
export async function getProvidersConfig() {
  return {
    providers: [
      {
        id: "gemini",
        name: "Google Gemini",
        model: "gemini-2.5-flash",
        requiresKey: true,
      },
      {
        id: "openai",
        name: "OpenAI GPT-4",
        model: "gpt-4o-mini",
        requiresKey: true,
      },
      {
        id: "claude",
        name: "Anthropic Claude",
        model: "claude-sonnet-4-5",
        requiresKey: true,
      },
    ],
    activeProvider: await getActiveLLMProvider(),
  };
}

export async function setActiveProvider(provider: LLMProvider) {
  try {
    await dbHelpers.setSetting(
      "active_llm_provider",
      provider,
      "Active LLM provider",
    );
    return { success: true, provider };
  } catch (error) {
    console.error("Error setting active provider:", error);
    throw error;
  }
}

// ─── Template Type Detection ───────────────────────────────────────────────────
export async function detectTemplateType(
  userInput: string,
  provider: LLMProvider = "gemini",
): Promise<"invoice" | "quotation" | "proposal"> {
  try {
    const result = await generateObject({
      model: getModel(provider),
      system: `Classify: invoice (billing after completed work), quotation (price estimate before work), proposal (detailed project plan with scope/timeline).`,
      prompt: `"${userInput}"`,
      schema: z.object({
        detectedType: z.enum(["invoice", "quotation", "proposal"]),
      }),
    });
    return result.object.detectedType;
  } catch {
    return detectTemplateTypeHeuristic(userInput);
  }
}

function detectTemplateTypeHeuristic(
  userInput: string,
): "invoice" | "quotation" | "proposal" {
  const input = userInput.toLowerCase();
  if (
    ["invoice", "bill", "payment due", "billing", "amount due"].some((kw) =>
      input.includes(kw),
    )
  )
    return "invoice";
  if (
    ["proposal", "project", "bid", "scope", "timeline", "deliverables"].some(
      (kw) => input.includes(kw),
    )
  )
    return "proposal";
  return "quotation";
}
