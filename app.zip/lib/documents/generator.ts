import { extractDocumentData } from '../ai';
import { dbHelpers } from '../db/mock-db';
import Handlebars from 'handlebars';

interface GenerateDocumentInput {
  templateType: 'invoice' | 'quotation' | 'proposal';
  userInput: string;
  memoryContext?: Record<string, any>;
  llmProvider?: 'gemini' | 'openai' | 'claude';
}

interface GenerateDocumentOutput {
  success: boolean;
  html: string;
  json: Record<string, any>;
  fileName: string;
  message?: string;
  error?: string;
}

// Default HTML template (same for all - will be customized per type later)
const DEFAULT_HTML_TEMPLATE = `
<div style="font-family: Arial, sans-serif; padding: 40px; max-width: 800px; margin: 0 auto;">
  <div style="display: flex; justify-content: space-between; margin-bottom: 40px;">
    <div>
      <h1 style="margin: 0; text-transform: uppercase;">{{#if invoiceNumber}}Invoice{{else}}{{#if quotationNumber}}Quotation{{else}}Proposal{{/if}}{{/if}}</h1>
      {{#if invoiceNumber}}<p style="color: #666; margin: 5px 0;">Invoice #: {{invoiceNumber}}</p>{{/if}}
      {{#if quotationNumber}}<p style="color: #666; margin: 5px 0;">Quotation #: {{quotationNumber}}</p>{{/if}}
      {{#if proposalNumber}}<p style="color: #666; margin: 5px 0;">Proposal #: {{proposalNumber}}</p>{{/if}}
      {{#if invoiceDate}}<p style="color: #666; margin: 5px 0;">Date: {{invoiceDate}}</p>{{/if}}
      {{#if quotationDate}}<p style="color: #666; margin: 5px 0;">Date: {{quotationDate}}</p>{{/if}}
      {{#if proposalDate}}<p style="color: #666; margin: 5px 0;">Date: {{proposalDate}}</p>{{/if}}
      {{#if dueDate}}<p style="color: #666; margin: 5px 0;">Due: {{dueDate}}</p>{{/if}}
    </div>
    <div style="text-align: right;">
      {{#if companyName}}<h3>{{companyName}}</h3>{{/if}}
      {{#if companyAddress}}<p style="color: #666; margin: 5px 0;">{{companyAddress}}</p>{{/if}}
    </div>
  </div>

  <div style="margin-bottom: 30px;">
    <h3>{{#if clientName}}Bill To:{{/if}}</h3>
    {{#if clientName}}<p style="margin: 5px 0;"><strong>{{clientName}}</strong></p>{{/if}}
    {{#if clientEmail}}<p style="color: #666; margin: 5px 0;">{{clientEmail}}</p>{{/if}}
    {{#if clientAddress}}<p style="color: #666; margin: 5px 0;">{{clientAddress}}</p>{{/if}}
  </div>

  {{#if items}}
  <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
    <thead>
      <tr style="background-color: #f5f5f5;">
        <th style="padding: 10px; text-align: left; border-bottom: 2px solid #333;">Description</th>
        <th style="padding: 10px; text-align: center; border-bottom: 2px solid #333;">Qty</th>
        <th style="padding: 10px; text-align: right; border-bottom: 2px solid #333;">Price</th>
        <th style="padding: 10px; text-align: right; border-bottom: 2px solid #333;">Amount</th>
      </tr>
    </thead>
    <tbody>
      {{#each items}}
      <tr style="border-bottom: 1px solid #ddd;">
        <td style="padding: 10px; text-align: left;">{{this.description}}</td>
        <td style="padding: 10px; text-align: center;">{{this.quantity}}</td>
        <td style="padding: 10px; text-align: right;">\${{this.unitPrice}}</td>
        <td style="padding: 10px; text-align: right;">\${{this.amount}}</td>
      </tr>
      {{/each}}
    </tbody>
  </table>
  {{/if}}

  {{#if total}}
  <div style="margin-left: auto; width: 300px; margin-bottom: 20px;">
    {{#if subtotal}}<div style="display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #ddd;">
      <span>Subtotal:</span>
      <strong>\${{subtotal}}</strong>
    </div>{{/if}}
    {{#if tax}}<div style="display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #ddd;">
      <span>Tax:</span>
      <strong>\${{tax}}</strong>
    </div>{{/if}}
    <div style="display: flex; justify-content: space-between; padding: 10px 0; font-size: 18px; font-weight: bold;">
      <span>Total:</span>
      <strong>\${{total}}</strong>
    </div>
  </div>
  {{/if}}

  {{#if cost}}
  <div style="display: flex; justify-content: space-between; padding: 15px 0; font-size: 18px; font-weight: bold; border-top: 2px solid #333;">
    <span>Total Cost:</span>
    <strong>\${{cost}}</strong>
  </div>
  {{/if}}

  {{#if notes}}<div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd;">
    <h4>Notes:</h4>
    <p style="color: #666;">{{notes}}</p>
  </div>{{/if}}

  {{#if scope}}<div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd;">
    <h4>Scope of Work:</h4>
    <p style="color: #666;">{{scope}}</p>
  </div>{{/if}}

  <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #ddd; text-align: center; color: #999; font-size: 12px;">
    <p>Thank you for your business!</p>
  </div>
</div>
`;

// Compile Handlebars template once
const templateCache = new Map<string, HandlebarsTemplateDelegate<any>>();

function compileTemplate(templateStr: string) {
  if (templateCache.has(templateStr)) {
    return templateCache.get(templateStr)!;
  }
  const compiled = Handlebars.compile(templateStr);
  templateCache.set(templateStr, compiled);
  return compiled;
}

// Default skill prompts
const skillPrompts = {
  invoice: `You are an expert data extraction specialist. Extract invoice information from the user's input and return ONLY a valid JSON object matching this structure (no markdown, no code blocks, just JSON):
{
  "clientName": "Client name",
  "clientEmail": "client@example.com",
  "clientAddress": "123 Main St",
  "invoiceNumber": "INV-001",
  "invoiceDate": "2024-01-15",
  "dueDate": "2024-02-15",
  "items": [{"description": "Service description", "quantity": 1, "unitPrice": 100, "amount": 100}],
  "subtotal": 100,
  "tax": 10,
  "total": 110,
  "notes": "Thank you",
  "companyName": "Your Company",
  "companyAddress": "456 Business Ave"
}`,
  quotation: `You are an expert data extraction specialist. Extract quotation information from the user's input and return ONLY a valid JSON object matching this structure (no markdown, no code blocks, just JSON):
{
  "clientName": "Client name",
  "clientEmail": "client@example.com",
  "clientAddress": "123 Main St",
  "quotationNumber": "QT-001",
  "quotationDate": "2024-01-15",
  "validUntil": "2024-02-15",
  "items": [{"description": "Service description", "quantity": 1, "unitPrice": 100, "amount": 100}],
  "subtotal": 100,
  "tax": 10,
  "total": 110,
  "notes": "Terms and conditions",
  "companyName": "Your Company",
  "companyAddress": "456 Business Ave"
}`,
  proposal: `You are an expert data extraction specialist. Extract proposal information from the user's input and return ONLY a valid JSON object matching this structure (no markdown, no code blocks, just JSON):
{
  "clientName": "Client name",
  "clientEmail": "client@example.com",
  "clientAddress": "123 Main St",
  "proposalNumber": "PROP-001",
  "proposalDate": "2024-01-15",
  "proposalTitle": "Project Title",
  "introduction": "Project introduction",
  "objectives": ["Objective 1", "Objective 2"],
  "scope": "Scope of work",
  "deliverables": ["Deliverable 1", "Deliverable 2"],
  "timeline": "3 months",
  "cost": 5000,
  "terms": "Payment terms",
  "notes": "Additional notes",
  "companyName": "Your Company",
  "companyAddress": "456 Business Ave"
}`,
};

export async function generateDocument(
  input: GenerateDocumentInput
): Promise<GenerateDocumentOutput> {
  try {
    // Get skill prompt for this template type
    const skillContent = skillPrompts[input.templateType];

    if (!skillContent) {
      return {
        success: false,
        html: '',
        json: {},
        fileName: '',
        error: `No skill found for template type: ${input.templateType}`,
      };
    }

    // Extract data using LLM
    const extractedJson = await extractDocumentData({
      userPrompt: input.userInput,
      templateType: input.templateType,
      skillContent,
      memoryContext: input.memoryContext,
      provider: input.llmProvider,
    });

    // Compile and render template
    const compiled = compileTemplate(DEFAULT_HTML_TEMPLATE);
    const html = compiled(extractedJson);

    // Generate file name
    const timestamp = new Date().toISOString().split('T')[0];
    const documentNumber =
      extractedJson.invoiceNumber ||
      extractedJson.quotationNumber ||
      extractedJson.proposalNumber ||
      'DOC';
    const fileName = `${input.templateType}_${documentNumber}_${timestamp}.html`;

    // Save to mock database
    try {
      await dbHelpers.saveDocument({
        templateId: 1,
        userInput: input.userInput,
        extractedJson: JSON.stringify(extractedJson),
        generatedHtml: html,
        fileName,
      });
    } catch (dbError) {
      console.error('Error saving document to database:', dbError);
      // Continue even if database save fails
    }

    return {
      success: true,
      html,
      json: extractedJson,
      fileName,
      message: 'Document generated successfully',
    };
  } catch (error) {
    console.error('Error generating document:', error);
    return {
      success: false,
      html: '',
      json: {},
      fileName: '',
      error: error instanceof Error ? error.message : 'Unknown error occurred',
    };
  }
}

// Generate PDF from HTML (you'll need to add a PDF library)
export async function generatePDF(html: string): Promise<Buffer> {
  // This is a placeholder - you would use a library like puppeteer or pdfkit
  // For now, we'll return the HTML as-is
  // TODO: Implement PDF generation using pdfkit or similar
  throw new Error('PDF generation not yet implemented. Use the HTML directly.');
}
