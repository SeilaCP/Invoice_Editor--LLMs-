"use server";

import { generateDocument } from "@/lib/documents/generator";
import { dbHelpers } from "@/lib/db/mock-db";
import {
  getProvidersConfig,
  setActiveProvider,
  detectTemplateType,
  detectIntent,
  generateChatResponse,
} from "@/lib/ai";

// ─── Init ──────────────────────────────────────────────────────────────────────
let initialized = false;

export async function ensureDatabaseInitialized() {
  if (!initialized) {
    try {
      initialized = true;
      return { success: true };
    } catch (error) {
      console.error("Failed to initialize database:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      };
    }
  }
  return { success: true };
}

// ─── Document Generation ───────────────────────────────────────────────────────
export async function generateDocumentAction(input: {
  templateType: "invoice" | "quotation" | "proposal";
  userInput: string;
  llmProvider?: "gemini" | "openai" | "claude";
}) {
  try {
    const result = await generateDocument({
      templateType: input.templateType,
      userInput: input.userInput,
      llmProvider: input.llmProvider,
    });
    return result;
  } catch (error) {
    console.error("Error in generateDocumentAction:", error);
    return {
      success: false,
      html: "",
      json: {},
      fileName: "",
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

// ─── Chat + Document Router ────────────────────────────────────────────────────
export async function handleUserMessage(
  userMessage: string,
  conversationHistory: Array<{
    role: "user" | "assistant";
    content: string;
  }> = [],
  llmProvider?: "gemini" | "openai" | "claude",
) {
  try {
    // ── Hard guard: obvious non-document input never reaches LLM classification ──
    const trimmed = userMessage.trim();
    const wordCount = trimmed.split(/\s+/).length;
    const hasAmount =
      /\$[\d,]+|\d+\s*(usd|dollars?|€|£)|[\d]+\s*hours?|\d+\/hr/i.test(trimmed);
    const hasDocumentKeyword =
      /\b(invoice|quotation|quote|proposal|bill)\b/i.test(trimmed);
    const isObviouslyChat =
      wordCount <= 4 || // too short to be a document request
      !hasAmount || // no price = definitely chat
      (!hasDocumentKeyword && wordCount < 8); // no doc keyword + short = chat

    if (isObviouslyChat) {
      const reply = await generateChatResponse(
        trimmed,
        conversationHistory,
        llmProvider,
      );
      return { success: true, type: "chat" as const, message: reply };
    }

    // ── Intent detection (only runs for longer, data-rich messages) ──
    const { intent, templateType, confidence } = await detectIntent(
      trimmed,
      llmProvider,
    );

    if (intent === "chat" || confidence < 0.65) {
      const reply = await generateChatResponse(
        trimmed,
        conversationHistory,
        llmProvider,
      );
      return { success: true, type: "chat" as const, message: reply };
    }

    // ── Document generation ──
    try {
      const docType =
        templateType || (await detectTemplateType(trimmed, llmProvider));
      const result = await generateDocumentAction({
        templateType: docType,
        userInput: trimmed,
        llmProvider,
      });

      if (!result.success) {
        // Not enough data — ask user for missing info
        const reply = await generateChatResponse(
          `The user tried to create a ${docType} but the message "${trimmed}" didn't have enough information. Ask them specifically what's missing: client name, services/items, amounts, and dates.`,
          [],
          llmProvider,
        );
        return { success: true, type: "chat" as const, message: reply };
      }

      return {
        success: true,
        type: "document" as const,
        templateType: docType,
        message: `Your ${docType} is ready!`,
        html: result.html,
        json: result.json,
        fileName: result.fileName,
      };
    } catch (docError) {
      // Document generation failed — fall back to chat gracefully
      console.error(
        "Document generation failed, falling back to chat:",
        docError,
      );
      const reply = await generateChatResponse(
        `The user said: "${trimmed}". They may want a document but didn't provide enough detail. Ask them what they'd like to create and what information to include.`,
        conversationHistory,
        llmProvider,
      );
      return { success: true, type: "chat" as const, message: reply };
    }
  } catch (error) {
    console.error("Error in handleUserMessage:", error);
    return {
      success: false,
      type: "chat" as const,
      message: "Something went wrong. Please try again.",
    };
  }
}

// ─── Memory ────────────────────────────────────────────────────────────────────
export async function getMemories() {
  try {
    const allMemories = await dbHelpers.getMemories();
    return { success: true, memories: allMemories };
  } catch (error) {
    console.error("Error getting memories:", error);
    return {
      success: false,
      memories: [],
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

export async function saveMemory(
  key: string,
  content: Record<string, any>,
  description?: string,
) {
  try {
    await dbHelpers.saveMemory(key, content, description);
    return { success: true };
  } catch (error) {
    console.error("Error saving memory:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

export async function deleteMemory(key: string) {
  try {
    await dbHelpers.deleteMemory(key);
    return { success: true };
  } catch (error) {
    console.error("Error deleting memory:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

// ─── Provider Settings ─────────────────────────────────────────────────────────
export async function getProviderSettings() {
  try {
    const config = await getProvidersConfig();
    return { success: true, ...config };
  } catch (error) {
    console.error("Error getting provider settings:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

export async function setActiveProviderAction(
  provider: "gemini" | "openai" | "claude",
) {
  try {
    const result = await setActiveProvider(provider);
    return { success: true, ...result };
  } catch (error) {
    console.error("Error setting active provider:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

export async function saveAPIKey(
  provider: "gemini" | "openai" | "claude",
  apiKey: string,
) {
  try {
    await dbHelpers.setSetting(
      `${provider}_api_key`,
      apiKey,
      `API key for ${provider}`,
    );
    return { success: true };
  } catch (error) {
    console.error("Error saving API key:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

export async function detectTemplateTypeAction(
  userInput: string,
  provider?: "gemini" | "openai" | "claude",
) {
  try {
    const detectedType = await detectTemplateType(userInput, provider);
    return { success: true, detectedType };
  } catch (error) {
    console.error("Error detecting template type:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
      detectedType: "quotation" as const,
    };
  }
}
